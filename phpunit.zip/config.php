<?php


//this setting controls database functionality
// 0 - no database use
// 1 - MySQL database use
// 2 - DynamoDB database use
$databaseUse = 0;

//this controls whether the load generator is accessible
//values are:
// 0 - no access
// 1 - allow access
$loadGenUse = 0;

?>
